import UIKit
/*:
# Playground - Actividad 5
* Class y Struct
* Extension
* Optional
*/
//Ignacio Landín López - 02905539

/*: 
### Actividad Class y Struct
A) Diseñar la clase Persona que contenga dos metodos, el primero "Saludar" que reciba el parámetro nombre y regrese el mensaje el nombre mas el texto "mucho gusto", el segundo metodo "Caminar" que reciba como parámetro un tipo de dato Int y regrese un tipo de dato String indicando el numero de pasos caminados.
*/
class Persona {

var nombre:String, saludar = ""
var caminar:Int, camino = 0
    
    init(nombre:String, caminar:Int)
    {
        self.nombre = nombre
        self.caminar = caminar
    }
    
    func Caminado(pasos:Int){
        self.camino = pasos
    }
    
    func Mensaje(texto:String){
        self.saludar = texto
    }
}

var saludo = Persona(nombre: "Nacho", caminar: 0)
saludo.Caminado(pasos: 24)
saludo.Mensaje(texto: "Mucho Gusto")

print("Hola \(saludo.nombre)! \(saludo.saludar), caminaste: \(saludo.camino) pasos.")
//: B) Diseñar el struct "Pantalla" la cual recibirá como como parametros el ancho y alto de una pantalla como tipo de datos Int con un constructor, para inicializar la estructura.
struct Pantalla
{
    var ancho:Int
    var alto:Int
    
    init(ancho:Int, alto:Int){
        self.ancho = ancho
        self.alto = alto
    }
    
    func PantallaResolucion() -> (Int, Int) {
        return (self.ancho, self.alto)
    }
}

var cuatrok = Pantalla(ancho: 4096, alto: 2160)
var uhd = Pantalla(ancho: 3840, alto: 2060)

cuatrok.PantallaResolucion()
uhd.PantallaResolucion()

print("Resolucion: \(uhd.PantallaResolucion())")
/*:
### Extensions
A) Diseñar un extensión del tipo de dato Int que represente las horas y que pueda regresar los segundos correspondientes (puedes utilizar una función o una variable computada)
*/
extension Int{
    func segundos() -> Int {
        return self*24*86
    }
}
3.segundos()

//: B) Diseñar una extensión del tipo de dato String que represente un día de la semana y regrese el numero correspondiente iniciando con Domingo = 1 y finalizando Sábado = 7
extension String{

    //var dia:String{
            //}
}

/*:
### Optionals
A) Diseñar una variable optional para recibir el tipo de dato Int en caso de que exista.
*/
//var existe:Int?
//: B) Para la colección let dias = ["GDL":120, "PUE":300, "MTY":100, "CDMX":200] diseñar una variable opcional para recibir el valor de dias["DF"]
var dias = ["GDL":1, "PUE":300, "MTY":100, "CDMX":200]
var existe:Int?
existe = dias["DF"]
existe = dias["PUE"]
if let temp = dias["DF"]{
print("Dias:")
} else{
print("diasno: ")
}




