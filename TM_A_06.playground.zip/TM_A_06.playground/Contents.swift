import UIKit
/*:
# Playground - Actividad 6
* Operadores personalizados
* Subscripts
* Control de errores

*/
//Ignacio Landín López - 02905539

/*: 
### Operadores personalizados
A) Crear el operador para realizar la potencia de el valor "a" a la potencia "b" en valores enteros
*/
prefix operator +++
prefix func +++(valor:Int)->Int
{
    let v = valor + valor
    return v
}

+++3
+++5
//: B) Crear el operador |> para ordenar la colección [2,5,3,4] de menor a mayor
infix operator |>
func primeroMayor(s1: String, s2: String) -> Bool {
    return s2 > s1
}
let numeros = ["2", "5", "3", "4"]
let alreves = numeros.sorted(by: primeroMayor)
print(alreves)
/*:
### Subscripts
A) Del conjunto de datos en el Array [2,3,4,5], crear el subscript para modificar los valores multiplicados por el valor 2 y extraer al valor dado un índice.
*/
let cantidades = [2,3,4,5]

class Cantidad
{
    var valores:[Int]
    init(v:[Int])
    {
        self.valores = v
    }
    
    subscript(idx:Int) -> Int
    {
        get {
            return valores[idx]
        }
        set (nuevoValor)
        {
            valores[idx] = nuevoValor
        }
    }
}

let v1 = Cantidad(v: cantidades)
v1[3]

/*:
### Control de Errores
A) Crear la función ExisteValor en la cual se reciba como parámetro el valor a buscar dentro de un colección ["A":1, "B":2,"C":3]
*/
let dictError = [1:"A", 2:"B", 3:"C"]

func ExisteValor (idx:Int)
{
    guard let existe = dictError [idx] else{
        print("no existe")
        return
    }
    print ("existe \(existe)")
}

ExisteValor(idx: 3)
ExisteValor(idx: 4)






