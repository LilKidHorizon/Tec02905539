import UIKit
/*:
# Playground - Actividad 3
* Tipos de datos
* Asociación de tipos
* Arreglos y Diccionarios
*/
//IGNACIO LANDÍN LÓPEZ - 02905539

/*: 
### Actividad de Tipos de datos
A) Declarar cuatro variables con tres diferentes tipos de datos, cada uno que corresponda a una numero entero, un numero decimal (flotante), una cadena de texto, realizando la asignación explicita y la asignación inferida
*/
var grupos = 3
let otro_grupos:Int = 6

var calificacion = 8.9
let otro_calificacion:Float = 7.4

var nombre = "Ignacio"
let otro_nombre:String = "Landin"



/*:
### Asociación de tipos
A) Declara el tipo de dato por asociación para un tipo de dato String
*/
var dato1:String = String()
//: B) Declara el tipo de dato por asociación para un tipo de dato  Número entero.
var dato2:Int = Int()


/*: 
### Arreglos y Diccionarios
A) Crea la variable "numeros" de tipo Array con números consecutivos del 1 a 10.
*/
var numeros:Array<Int> = Array<Int>()
numeros.append(1)
numeros.append(2)
numeros.append(3)
numeros.append(4)
numeros.append(5)
numeros.append(6)
numeros.append(7)
numeros.append(8)
numeros.append(9)
numeros.append(10)
numeros.count

//: B) Crea la variable "diasSemana" de tipo Dictionary con la relación numero:día Ej. 1:"Lunes"
var diasSemana:Dictionary<String, Int> = Dictionary<String, Int>()
diasSemana["Lunes"] = 1
diasSemana["Martes"] = 2
diasSemana["Miercoles"] = 3
diasSemana["Jueves"] = 4
diasSemana["Viernes"] = 5
diasSemana["Sabado"] = 6
diasSemana["Domingo"] = 7
print("Dias de la semana: \(diasSemana)")

/*:
### Condicionales y Ciclos
A) Declarar la variable "datos" con los valores [3,6,9,2,4,1]
*/
//NO LO PIDE LA ACT
//: B) realizar el recorrido de la variable "datos" con la instrucción "for"
//NO LO PIDE LA ACT

//: C) Encontrar los valores menores a 5
//NO LO PIDE LA ACT




