//
//  Celda.swift
//
//
//  Created by Ignacio Landin on 06/05/21.
//

import UIKit

class Celda: UICollectionViewCell {
    @IBOutlet weak var imagenNum: UIImageView!
}
